---
name: email-style-profile
description: This skill should be used when the user asks to "write like me", "match my email tone", "learn my signatures", or wants the assistant to capture voice, structure, greeting/closing habits, and length preferences before drafting mail. Reads mostly via search_emails (Sent mailbox corpus), get_email_thread(account=..., ...), get_email_by_id and supplements with USER_EMAIL_PREFERENCES injection; hands off drafting to email-drafting. Do NOT use for inbox cleanup (email-management), archiving (email-archive-cleanup), or Mail setup errors (apple-mail-operator).
---

# Email Style Profile

Establish a repeatable **voice contract** derived from observable mail plus explicit preferences.

## Large-inbox pre-flight (required when Sent mailbox is large)

See [`large-inbox-rules.md`](references/large-inbox-rules.md) for the canonical pre-flight checklist. The Sent-mail harvest below uses bounded `recent_days` windows; never pass `recent_days=0`.

## Workflow

### 1. Gather Explicit Preferences First

Collect explicit bullets (or ingest existing notes from the user) covering:

- Formality ladder (investor memo vs teammate ping).
- Default greeting/sign-off patterns (including language toggles).
- Paragraph length norms, bullets vs prose, emoji policy.
- Red lines (topics not to auto-generate).

Encode durable preferences inside **`USER_EMAIL_PREFERENCES`** so every preference-aware MCP tool inherits the context.

### 2. Harvest Sent-Mail Samples Read-Only

| Step | Tool call |
|------|-----------|
| Pull recent Sends | `search_emails(mailbox="Sent", include_content=true, recent_days=30, limit=15)`; on large mailboxes, follow this ladder: try `recent_days=7` first; if timeouts, drop to `3`; if still slow, anchor on a specific `message_id` from a known recent Send. If the user insists on the full Sent corpus, page bounded `search_emails(mailbox="Sent", limit=50, offset=N)` calls (or `export_emails(scope="entire_mailbox", mailbox="Sent", max_emails=50, offset=N)`) rather than ratcheting `recent_days`; `full_inbox_export` is disabled (`UNBOUNDED_EXPORT_DISABLED`) and never a shortcut; never pass `recent_days=0` |
| Deepen hallmark threads | `get_email_by_id(message_id="...")` or `get_email_thread(message_id="...")`; if no id yet, run bounded `search_emails` or `list_inbox_emails` first and pass the returned `message_id` |
| Check alternate aliases | Cross-check `list_account_addresses` outputs if tone shifts per persona |

Interpret samples **summaristically**; do not stash full bodies into long-term prose outside the negotiated profile document the user accepts.

### 3. Produce A Style Ledger

Deliver a concise artifact (bullet list acceptable) containing:

- Voice adjectives + example phrases sanitized of PII unless user consents.
- Structural habits (lead with ask vs context-first).
- Signature components and escalation paths (“when to CC legal/finance”).
- Anti-patterns to avoid inferred from frustrations the user mentions.

### 4. Wire Into Draft Flow

Always cross-link to **`email-drafting`** for actual compose operations. Mention when **draft-safe** mode means output must stop at drafts pending human send. Reply-style examples must be authored via `reply_to_email(message_id=..., reply_body=...)`, not `compose_email` or `create_rich_email_draft`; the latter now refuse `Re:`/`Fwd:` drafts unless `standalone_confirmed=True`. Default `native_format=True` on replies needs Mail focus + Accessibility; hand off `REPLY_WINDOW_FOCUS_FAILED` recovery to **`email-drafting`**.

### 5. Maintain And Refresh

Recommend re-sync after major role changes quarterly or whenever the user says responses “sound off”. Use narrower `recent_days` window for refreshes unless they request historical study.

## Guardrails

- Never impersonate humans outside authorized mailbox scope.
- If Sent-mail samples are insufficient, pause and gather **two** real examples before guessing voice.
- When privacy policies forbid training on mail, revert to declarative **`USER_EMAIL_PREFERENCES`** only.

## Related Skills

- **`email-drafting`**: operational compose/draft/send guardrails (subject to `--draft-safe`).
- **`apple-mail-operator`**: fix account enumeration issues blocking Sent pulls.
