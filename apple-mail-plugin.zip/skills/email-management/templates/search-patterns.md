# ID-First Email Search Patterns

Use search as discovery, not action authorization. Search tools return candidate handles. Action tools operate on exact handles such as `message_id`, `draft_id`, or a future exact attachment selector.

## Core Workflow

1. Run a bounded discovery query.
2. Review the returned subjects, senders, accounts, mailboxes, dates, and ids.
3. Collect exact `message_id` values from the reviewed candidate set.
4. Call action tools with `message_ids=[...]` and a clear cap.
5. Use `dry_run=True` before moves, status updates, trash operations, or large attachment saves.

```python
results = search_emails(
    account="Work",
    mailbox="INBOX",
    subject_keyword="Project Alpha",
    recent_days=7,
    limit=10,
    output_format="json",
)

ids = [item["message_id"] for item in results["items"]]
# Review subjects, senders, dates, mailboxes, and ids before acting.
move_email(dry_run=True, message_ids=ids, to_mailbox="Projects/Alpha", max_moves=len(ids))
move_email(dry_run=False, message_ids=ids, to_mailbox="Projects/Alpha", max_moves=len(ids))
```

Do not pass subject, sender, or draft-subject selectors to action tools. Those legacy selectors return `TARGET_SELECTOR_DEPRECATED` on action surfaces.

## Discovery Tools

Use `list_inbox_emails` for a fast recent inbox skim. Use `search_emails` for bounded discovery across date, subject, sender, read status, attachments, and explicit mailbox sets. Use `get_email_by_id` when an exact Mail id is already known.

```python
recent = list_inbox_emails(
    account="Work",
    max_emails=20,
    include_read=True,
    include_content=False,
    output_format="json",
)

matches = search_emails(
    account="Work",
    mailbox="INBOX",
    recent_days=7,
    limit=20,
    output_format="json",
)
```

`search_emails` defaults to a recent bounded window. If you need a larger search, widen deliberately with `recent_days=7`, `recent_days=30`, or an explicit `date_from`. `recent_days=0` without `date_from` is refused with `UNBOUNDED_SCAN_REQUIRED`.

## Subject Discovery

Subject keywords are candidate discovery only. They are useful for finding likely ids, then the follow-up action must use ids.

```python
results = search_emails(
    account="Work",
    mailbox="INBOX",
    subject_keyword="board packet",
    recent_days=14,
    limit=10,
    output_format="json",
)

ids = [item["message_id"] for item in results["items"]]
```

Use narrower terms when broad terms return too many candidates. Prefer adding `mailbox`, `recent_days`, `read_status`, `has_attachments`, or sender filters instead of expanding to every folder.

## Sender Discovery

Prefer exact sender or domain filters when known.

```python
from_person = search_emails(
    account="Work",
    mailbox="INBOX",
    sender_exact="person@example.com",
    recent_days=30,
    limit=25,
    output_format="json",
)

from_domain = search_emails(
    account="Work",
    mailboxes=["INBOX", "Archive", "Sent"],
    sender_domain="example.com",
    recent_days=30,
    limit=50,
    output_format="json",
)
```

Use fuzzy `sender="..."` only when the exact address or domain is unknown, and keep it bounded with account, mailbox, date window, and limit.

## Explicit Mailbox Sets

Prefer a short explicit mailbox list over the whole-account search path.

```python
results = search_emails(
    account="Work",
    mailboxes=["INBOX", "Sent", "Archive"],
    subject_keyword="closing checklist",
    recent_days=30,
    limit=25,
    output_format="json",
)
```

Whole-account mailbox search is a capped fallback for cases where the likely folder is unknown. Use it only after narrower mailbox choices fail, and expect warnings about incomplete results on accounts with many labels or folders.

## Date And Status Discovery

```python
unread = search_emails(
    account="Work",
    mailbox="INBOX",
    read_status="unread",
    recent_days=7,
    limit=50,
    output_format="json",
)

range_results = search_emails(
    account="Work",
    mailboxes=["INBOX", "Archive"],
    date_from="2026-01-01",
    date_to="2026-01-31",
    limit=100,
    output_format="json",
)
```

Date-only and status-only queries can still produce many candidates. Review result counts and ids before any mutation.

## Attachment Discovery

Find candidate messages with `has_attachments=True`, then list or save attachments by exact `message_ids`.

```python
candidates = search_emails(
    account="Work",
    mailbox="INBOX",
    has_attachments=True,
    sender_domain="example.com",
    recent_days=30,
    limit=20,
    output_format="json",
)

ids = [item["message_id"] for item in candidates["items"]]
list_email_attachments(message_ids=ids, max_results=20)
```

`save_email_attachment` should be called after the candidate message ids are known. Prefer exact attachment names. Ambiguous duplicate names remain a design item until exact attachment ids are surfaced.

## Threads And Replies

When a search or list result contains a `message_id`, use that id for the thread and reply flow.

```python
thread = get_email_thread(
    account="Work",
    message_id="12345",
    mailbox="INBOX",
    max_messages=20,
)

reply_to_email(
    account="Work",
    message_id="12345",
    reply_body="Thanks, I will review and follow up.",
    mode="draft",
)
```

Do not reply or forward by subject. If no id is known, run `search_emails` or `list_inbox_emails` first.

## Body Search

Body search is slow because it reads message contents. It requires explicit opt-in.

```python
body_matches = search_emails(
    account="Work",
    mailbox="INBOX",
    body_text="specific phrase",
    allow_body_scan=True,
    recent_days=7,
    limit=10,
    output_format="json",
)
```

Pair body search with a tight account, mailbox, date window, and limit. Use it for discovery only.

## Safe Action Patterns

### Move Reviewed Messages

```python
ids = ["101", "202"]
move_email(dry_run=True, message_ids=ids, to_mailbox="Archive/Reviewed", max_moves=len(ids))
move_email(dry_run=False, message_ids=ids, to_mailbox="Archive/Reviewed", max_moves=len(ids))
```

### Mark Reviewed Messages

```python
update_email_status(action="flag", message_ids=["101", "202"], max_updates=2)
update_email_status(action="mark_read", message_ids=["101", "202"], max_updates=2)
```

### Move Reviewed Messages To Trash

```python
manage_trash(action="move_to_trash", dry_run=True, message_ids=["101"], max_deletes=1)
manage_trash(action="move_to_trash", dry_run=False, message_ids=["101"], max_deletes=1)
```

Permanent delete and empty-trash operations need explicit confirmation and, for valuable mailboxes, an export first.

## Slow Or Broad Fallbacks

Use `full_inbox_export` for audited full-mailbox work rather than trying to bypass bounded search rules.

```python
full_inbox_export(
    account="Work",
    max_emails=1000,
    fields=["subject", "sender", "date", "message_id", "mailbox"],
    output_format="ndjson",
)
```

Treat exports and large scans as evidence-gathering steps. They do not authorize mutations by themselves.

## Anti-Patterns

Do not call action tools with subject, sender, or draft-subject selectors.
Do not make the whole-account mailbox scan the default discovery shape.

Use this instead:

```python
results = search_emails(
    account="Work",
    mailboxes=["INBOX", "Archive"],
    subject_keyword="Project Alpha",
    recent_days=30,
    limit=25,
    output_format="json",
)
ids = [item["message_id"] for item in results["items"]]
move_email(dry_run=True, message_ids=ids, to_mailbox="Archive", max_moves=len(ids))
```
